# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib import admin


class User(models.Model):
    username = models.CharField(max_length=200)  # 用户名
    userhash = models.CharField(max_length=40)  # 用户哈希值(随机)
    password = models.CharField(max_length=40)  # 密码
    active = models.BooleanField()  # 是否激活
    money = models.IntegerField()  # 金币(付费扫描)
    register = models.DateTimeField()  # 注册时间

    def __str__(self):
        return "用户模块"

    class Meta:
        ordering = ["username"]


class UserMeta(admin.ModelAdmin):
    list_display = ("username", "userhash", "active", "money", "register")


class Report(models.Model):
    uhash = models.CharField(max_length=40)  # 用户哈希值 用于鉴定该条报告的所属权
    thash = models.CharField(max_length=40)  # 任务哈希值 用户判断所述任务
    pname = models.CharField(max_length=500)  # 该属性用于描述报告上传插件的名字
    site = models.CharField(max_length=5000)  # 扫描站点
    level = models.IntegerField()  # 该报告危险等级
    report = models.TextField()  # 扫描报告的正文

    def __str__(self):
        return "报告模块"

    class Meta:
        ordering = ["uhash", "thash"]


class ReportMeta(admin.ModelAdmin):
    list_display = ("uhash", "site", "level", "report")


class Plugin(models.Model):
    uhash = models.CharField(max_length=40)  # 插件所属用户哈希值
    author = models.CharField(max_length=200)  # 插件作者
    froms = models.CharField(max_length=1000)  # 来源页面
    title = models.CharField(max_length=500)  # 插件名称
    private = models.BooleanField()  # 插件是否私有 该项用户在添加时不得更改，只能被动的设置成公有，需要通过后台才可以修改
    body = models.TextField()  # 插件正文，扫描插件的功能部分
    phash = models.CharField(max_length=40)  # 插件的哈希值 用于任务下发去重复部分

    def __str__(self):
        return "插件模块"

    class Meta:
        ordering = ["author"]


class PluginMeta(admin.ModelAdmin):
    list_display = ('pk',"author", "title", "private")


# 插件和扫描块的映射表
class plugin_scanblock_mapper(models.Model):
    phash = models.CharField(max_length=40)
    scan_fieldname = models.CharField(max_length=500)

    def __str__(self):
        return "插件扫描映射"


class plugin_scanblock_mapperMeta(admin.ModelAdmin):
    list_display = ["phash", "scan_fieldname"]


# 扫描块，用于在添加任务和添加插件的时候的分块
class Scan_block(models.Model):
    name = models.CharField(max_length=500)  # 该分块为在扫描时需要选择的扫描类型
    field_name = models.CharField(max_length=500)  # 此选项为上面的名字显示的对应的请求key的名字
    select = models.BooleanField()  # 默认选中状态

    def __str__(self):
        return "扫描板块"

    class Meta:
        ordering = ("name", "field_name", "select")


class Scan_blockMeta(admin.ModelAdmin):
    list_display = ("name", "field_name", "select")


# 任务和扫描块的映射表，防止大坑和数据重复
class task_scanblock_mapper(models.Model):
    thash = models.CharField(max_length=40)
    scan_fieldname = models.CharField(max_length=500)

    def __str__(self):
        return "任务和扫描映射表"


class task_scanblock_mapperMeta(admin.ModelAdmin):
    list_display = ["thash", "scan_fieldname"]


class Task(models.Model):
    thash = models.CharField(max_length=40)  # 属于任务的哈希值
    status = models.IntegerField()  # 该任务扫描的状态  0.添加  1.开始扫描 4 扫描结束
    scan_speed = models.IntegerField()  # 扫描速度(从前台获取的)
    uhash = models.CharField(max_length=40)  # 任务所属用户
    # 站点信息
    sites = models.CharField(max_length=150)  # 站点地址
    # 扫描选项

    # 扫描时添加我的插件
    myplugin = models.BooleanField()
    # 爬虫设置
    sub_domain = models.BooleanField()  # 扫描子域名
    deep_port_scan = models.BooleanField()  # 深度扫描端口
    # 全局设置
    speed = models.IntegerField()  # 扫描速度
    timeout = models.IntegerField()  # 超时时间
    max_pages = models.IntegerField()  # 最大扫描页面数量

    useragent = models.CharField(max_length=500)  # 扫描时的浏览器UA信息

    exlude = models.BooleanField()  # 跳过某些路径不扫
    exludetext = models.CharField(max_length=500)  # 上面选项对应的路径
    cook = models.TextField()  # 扫描页面需要的cookies

    def __str__(self):
        return "任务模块"


class TaskMeta(admin.ModelAdmin):
    list_display = ["uhash", "sites", "status", "scan_speed", "sub_domain", "deep_port_scan"]


class Node(models.Model):
    uhash = models.CharField(max_length=40)  # 节点所属用户
    tid = models.IntegerField()  # 该字段为挂节点的时候的唯一ID ，每次重启服务会重制
    platform = models.CharField(max_length=40)  # 节点平台
    version = models.CharField(max_length=40)  # 节点版本
    ip = models.CharField(max_length=40)  # 节点IP地址
    times = models.DateTimeField(auto_now=True)  # 节点上线时间

    def __str__(self):
        return "节点模块"


class NodeMeta(admin.ModelAdmin):
    list_display = ["uhash", "tid", "platform", "version", "ip", "times"]


admin.site.register(User, UserMeta)
admin.site.register(Task, TaskMeta)
admin.site.register(Plugin, PluginMeta)
admin.site.register(Report, ReportMeta)
admin.site.register(Node, NodeMeta)
admin.site.register(Scan_block, Scan_blockMeta)
admin.site.register(task_scanblock_mapper, task_scanblock_mapperMeta)
admin.site.register(plugin_scanblock_mapper, plugin_scanblock_mapperMeta)
