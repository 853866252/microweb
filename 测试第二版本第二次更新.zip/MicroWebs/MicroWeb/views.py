# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse
from MicroWeb.models import User
from MicroWeb.models import Task
from MicroWeb.models import Report
from MicroWeb.models import Node
from MicroWeb.models import Plugin
from MicroWeb.models import Scan_block
from MicroWeb.models import task_scanblock_mapper
from MicroWeb.models import plugin_scanblock_mapper
import load_plugin
from django.utils import timezone
import zlib
import os
import json
import util
import md5
import base64
import time
import sys
import binascii
import threading
import config
import json

num_Lock = threading.Lock()

node_num = 1

# default_encoding = 'utf-8'
# if sys.getdefaultencoding() != default_encoding:
#     reload(sys)
#     sys.setdefaultencoding(default_encoding)

reload(sys)
sys.setdefaultencoding("utf-8")  # 注册相关流程


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        passwords = request.POST["passwords"]
        if password == passwords and len(password) > 4 and len(username) > 4:
            if User.objects.filter(username=username):
                return render(request, "register.html", {"info": "该用户已被注册", "infotype": "info"})
            userhash = util.get_rand_str(16)
            while User.objects.filter(userhash=userhash):
                userhash = util.get_rand_str(16)
            User.objects.create(username=username, password=password, active=False, money=0, userhash=userhash,
                                register=timezone.now())
            return HttpResponseRedirect("/login/")
        return render(request, "register.html", {"info": "用户名或密码不符合规范", "infotype": "info"})
    return render(request, "register.html")


# 登陆相关
def login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        try:
            u = User.objects.get(username=username, password=password)
            uobj = {}
            uobj['id'] = u.pk
            uobj['username'] = u.username
            uobj['password'] = u.password
            uobj['active'] = u.active
            uobj['register'] = str(u.register)
            uobj['money'] = u.money
            uobj['uhash'] = u.userhash
            response = HttpResponseRedirect("/", {"info": "用户登录成功", 'infotype': "success"})
            request.session['users'] = uobj
            return response
        except Exception, e:
            return render(request, "login.html", {"info": "用户名密码错误", "infotype": "info"})
    return render(request, 'login.html', {"COOKIE": request.COOKIES.get('username', "")})


# 首页相关流程
def index(request):
    users = request.session.get('users', {})
    tasklen = Task.objects.filter(uhash=request.session.get('users', {}).get('uhash', "666"), status__lt=3).count()
    return render(request, 'index.html', {"users": users, 'tasklen': tasklen})


# 用户管理界面相关流程
def user(request):
    users = request.session.get('users', {})
    filepath = request.path
    mode = filepath.split("/")[2]

    if not users:
        return render(request, 'auth.html')
    if mode == "":
        return render(request, 'user/user.html',
                      {"users": users,
                       "tasklen": Task.objects.filter(uhash=request.session.get('users', {}).get('uhash', "666"),
                                                      status__lt=4).count()})
    elif mode == "logout":
        del request.session['users']
        return render(request, 'user/user.html',
                      {"users": {}, "info": "用户已经安全退出", "infotype": "danger"})
    else:
        pass


# 节点相关控制流程
def node(request):
    users = request.session.get('users', {})
    if not users:
        return render(request, "auth.html")
    mode = request.path.split("/")[2]
    if mode == "":
        unode = Node.objects.filter(uhash=users.get("uhash", "666"))
        online = []
        offlinelen = 0
        onlinelen = 0
        if unode:
            for node in unode:
                if int(time.mktime(timezone.now().timetuple()) - time.mktime(node.times.timetuple())) > 360:
                    node.delete()
                    continue
                tmpnode = {}
                tmpnode['platform'] = node.platform
                tmpnode['version'] = node.version
                tmpnode['ip'] = util.get_url_info(node.ip)[1]
                tmpnode['time'] = int(time.mktime(timezone.now().timetuple()) - time.mktime(node.times.timetuple()))
                online.append(tmpnode)
                if tmpnode['time'] > 60:
                    offlinelen += 1
                else:
                    onlinelen += 1
        return render(request, "node/node.html",
                      {"users": users, "info": "这是节点管理页面", "infotype": "danger",
                       'online': online, "alllen": len(online), 'onlinelen': onlinelen, "offlinelen": offlinelen})


def plugins(request):
    mode = request.path.split("/")[2]
    users = request.session.get('users', {})
    if not users:
        return render(request, "auth.html")
    if mode == "":
        plugin_list = Plugin.objects.filter(uhash=users.get("uhash", "666"))
        plu_list = []
        if plugin_list:
            for plugin in plugin_list:
                temp_plu = {}
                temp_plu['title'] = plugin.title
                temp_plu['froms'] = plugin.froms
                temp_plu['phash'] = plugin.phash
                temp_plu['level'] = "success"
                plu_list.append(temp_plu)
        return render(request, "plugins/plugin.html", {'users': users, "plugins": plu_list})
    elif mode == "add":
        if request.method == "POST" and users:
            phash = util.get_rand_str(16)
            while Plugin.objects.filter(phash=phash):
                phash = util.get_rand_str(16)
            Plugin.objects.create(
                uhash=users.get("uhash", "666"),
                author=request.POST.get("author", "admin"),
                froms=request.POST.get("froms", " "),
                title=request.POST.get("title", " "),
                private=True,
                body=request.POST.get("body", " "),
                phash=phash
            )
            for scan_block in Scan_block.objects.all():
                if request.POST.get(scan_block.field_name, "off") == "on":
                    plugin_scanblock_mapper.objects.create(phash=phash, scan_fieldname=scan_block.field_name)
            return HttpResponseRedirect("/plugins/")
        scan_block = Scan_block.objects.all()
        return render(request, "plugins/add.html", {'users': users, "scan_block": scan_block})
    elif mode == "del":
        if request.method == "POST":
            phash = request.POST.get("phash", "666")
            plugin = Plugin.objects.filter(phash=phash, uhash=users.get("uhash", "666"))
            if plugin:
                plugin.first().delete()
            mapper = plugin_scanblock_mapper.objects.filter(phash=phash)
            if mapper:
                mapper.delete()
            return HttpResponseRedirect("/plugins/")
        plugin = ""
        try:
            phash = request.path.split("/")[3]
            plugin = Plugin.objects.filter(uhash=users.get("uhash", "666"), phash=phash)
            if plugin:
                plugin = plugin.first()
        except:
            pass

        return render(request, "plugins/del.html", {"users": users, "plugin": plugin})
    elif mode == "edit":
        if request.method == "POST":
            plugin = Plugin.objects.filter(uhash=users.get("uhash"), phash=request.POST.get("phash", "666"))
            if plugin:
                plugin = plugin.first()
                phash = plugin.phash
                Plugin.objects.filter(uhash=users.get("uhash"), phash=request.POST.get("phash", "666")).update(
                    uhash=users.get("uhash", "666"),
                    author=request.POST.get("author", "admin"),
                    froms=request.POST.get("froms", " "),
                    title=request.POST.get("title", " "),
                    private=True,
                    body=request.POST.get("body", " "),
                    phash=phash,
                )
                plugin_scanblock_mapper.objects.filter(phash=phash).delete()
                for block in Scan_block.objects.all():
                    if request.POST.get(block.field_name, "off") == "on":
                        plugin_scanblock_mapper.objects.create(phash=phash, scan_fieldname=block.field_name)
            return HttpResponseRedirect("/plugins/")
        phash = "666"
        try:
            phash = request.path.split("/")[3]
        except:
            pass
        plugin = Plugin.objects.filter(uhash=users.get("uhash", "666"), phash=phash)
        if plugin:
            plugin = plugin.first()
            scan_block = Scan_block.objects.all()
            tmp_sblock = []
            plugin_type = plugin_scanblock_mapper.objects.filter(phash=phash)
            for s_block in scan_block:
                tmp = {}
                tmp['name'] = s_block.name
                tmp['field_name'] = s_block.field_name
                tmp['select'] = True if plugin_type.filter(scan_fieldname=s_block.field_name) else False
                tmp_sblock.append(tmp)
            return render(request, "plugins/edit.html",
                          {"users": users, "plugin": plugin, "scan_block": tmp_sblock})
        tasklen = Task.objects.filter(uhash=request.session.get('users', {}).get('uhash', "666"), status__lt=3).count()
        return render(request, "auth.html", {"users": users, 'tasklen': tasklen})


# 任务相关控制流程
def task(request):
    filepath = request.path
    mode = filepath.split("/")[2]
    users = request.session.get('users', {})
    if not users:
        return render(request, "auth.html")
    if mode == "tasks" or mode == "":
        uhash = users.get('uhash', "666")
        tasks = Task.objects.filter(uhash=uhash)
        if tasks:
            taskall = []
            taskok = 0
            tasknum = 0
            tasks = tasks.order_by("-pk")
            for t_tk in tasks:
                tasktmp = {'thash': t_tk.thash}
                tasktmp['site'] = t_tk.sites
                tasktmp['status'] = t_tk.status
                if not t_tk.status < 4:
                    tasktmp['speed'] = 100
                    taskok += 1
                else:
                    tasktmp['speed'] = t_tk.scan_speed
                    tasknum += 1
                level = Report.objects.filter(thash=t_tk.thash)
                if level:
                    level = level.order_by('-level')
                    tasktmp['level'] = {0: 'success', 1: 'info', 2: 'warning', 3: 'danger'}.get(level.first().level,
                                                                                                'success')
                else:
                    tasktmp['level'] = 'success'
                taskall.append(tasktmp)
            return render(request, "task/tasks.html",
                          {"users": users, 'tasks': taskall, 'tasknum': tasknum,
                           'taskok': taskok, 'layout': config.Layout})
        return render(request, "task/tasks.html", {"users": users, 'tasks': {}, 'layout': config.Layout})
    elif mode == "addtask":
        if request.method == "POST":
            if not request.POST.get('site', ''):
                return HttpResponseRedirect('/tasks/')
            thash = util.get_rand_str()
            while Task.objects.filter(thash=thash):
                thash = util.get_rand_str()
            for scan in Scan_block.objects.all():
                if request.POST.get(scan.field_name, "off") == "on":
                    task_scanblock_mapper.objects.create(thash=thash, scan_fieldname=scan.field_name)
            Task.objects.create(
                status=0,
                scan_speed=0,
                uhash=users.get("uhash", "666"),
                thash=thash,
                sites=request.POST.get('site', ''),
                myplugin=request.POST.get("myplugin", False) == "on",
                sub_domain=request.POST.get('sub_domain', False) == 'on',
                deep_port_scan=request.POST.get('deep_port_scan', False) == 'on',
                speed=int(request.POST.get('speed', 6)),
                timeout=request.POST.get('timeout', 24),
                max_pages=request.POST.get('max_pages', 7000),
                useragent=request.POST.get('useragent', ''),
                exlude=request.POST.get('exlude', False) == 'on',
                exludetext=request.POST.get('exludetext', ''),
                cook=request.POST.get('cookies', ''),
            )
            return HttpResponseRedirect('/tasks/')
        nodes = Node.objects.filter(uhash=users.get("uhash", "666"))
        show_node = []
        for node in nodes:
            if int(time.mktime(timezone.now().timetuple()) - time.mktime(node.times.timetuple())) > 360:
                node.delete()
                continue
            tmpnode = {}
            tmpnode['platform'] = node.platform
            tmpnode['version'] = node.version
            tmpnode['ip'] = util.get_url_info(node.ip)[1]
            tmpnode['time'] = int(time.mktime(timezone.now().timetuple()) - time.mktime(node.times.timetuple()))
            show_node.append(tmpnode)
        scan_block = Scan_block.objects.all()
        return render(request, "task/taskadd.html",
                      {"users": users, 'nodes': show_node, "scan_block": scan_block, "host": config.HOST,
                       "scheme": config.SCHEME})
    elif mode == "del":
        if request.method == "POST":
            thash = request.POST.get("thash", "666")
            task_del = Task.objects.filter(thash=thash, uhash=users.get("uhash", "666"))
            if task_del:
                task_scanblock_mapper.objects.filter(thash=thash).delete()
                Report.objects.filter(thash=thash).delete()
                task_del.delete()
            return HttpResponseRedirect("/tasks/")
        thash = "666"
        try:
            thash = request.path.split("/")[3]
        except:
            pass
        task = Task.objects.filter(thash=thash, uhash=users.get("uhash", "666"))
        if task:
            tmptask = {}
            tmptask['thash'] = task.first().thash
            tmptask['sites'] = task.first().sites
            return render(request, "task/del.html", {"users": users, "task": tmptask})
        return render(request, "task/del.html", {"users": users, "task": {}})
    elif mode == "stop":
        if request.method == "POST":
            thash = request.POST.get("thash", "666")
            task_stop = Task.objects.filter(thash=thash, uhash=users.get("uhash", "666"))
            if task_stop:
                task_stop.update(status=4, scan_speed=100)
            return HttpResponseRedirect("/tasks/")
        thash = "666"
        try:
            thash = request.path.split("/")[3]
        except:
            pass
        task = Task.objects.filter(thash=thash, uhash=users.get("uhash", "666"))
        if task:
            tmptask = {}
            tmptask['thash'] = task.first().thash
            tmptask['sites'] = task.first().sites
            return render(request, "task/stop.html", {"users": users, "task": tmptask})
        return render(request, "task/stop.html", {"users": users, "task": {}})
    elif mode == "delete":
        for task in Task.objects.filter(uhash=users.get("uhash", "666")):
            task_scanblock_mapper.objects.filter(thash=task.thash).delete()
            Report.objects.filter(thash=task.thash).delete()
            task.delete()
        return HttpResponseRedirect("/tasks/")


# 初始化节点
def initnode(request):
    if request.META.get("HTTP_USER_AGENT", None) != "Python-urllib/1.17":
        return render(request, "auth.html")

    def readFile(fn, buf_size=262144):
        f = open(fn, "rb")
        while True:
            c = f.read(buf_size)
            if c:
                yield c
            else:
                break
        f.close()

    filename_ = "init.py"
    filetype_ = "application/octet-stream"
    filepath_ = config.INIT_SITE

    response = HttpResponse(readFile(filepath_),
                            content_type='APPLICATION/OCTET-STREAM')
    response['Content-Disposition'] = 'attachment; filename=' + filename_.encode('utf-8') + filetype_.encode(
        'utf-8')
    response['Content-Length'] = os.path.getsize(filepath_)
    return response


# 初始化核心代码
def initcore(request):
    if request.META.get("HTTP_USER_AGENT", None) != "Python-urllib/2.7":
        return render(request, "auth.html")
    mode = request.path.split("/")[2]

    def readFile(fn, buf_size=262144):
        f = open(fn, "rb")
        while True:
            c = f.read(buf_size)
            if c:
                yield c
            else:
                break
        f.close()

    filename_ = "node"
    filetype_ = "application/octet-stream"
    if mode == "creat_node":
        filepath_ = config.NODE_SITE

        response = HttpResponse(readFile(filepath_),
                                content_type='APPLICATION/OCTET-STREAM')
        response['Content-Disposition'] = 'attachment; filename=' + filename_.encode('utf-8') + filetype_.encode(
            'utf-8')
        response['Content-Length'] = os.path.getsize(filepath_)
        return response


# 任务处理器
class TaskHandler:
    @staticmethod
    def handler(request):
        md5 = ""
        body = ""
        ip = None
        req = str(request.body)
        ip = request.get_host()
        if req:
            md5, body = req[:32], req[33:]
            body = zlib.decompress(base64.decodestring(body))
        result = TaskHandler.nullTask(json.loads(body))
        if util.md5(body) == md5:
            request = json.loads(body)
            intention = request['intention']
            if intention == "login":
                result = TaskHandler.login(request, ip)
            elif intention == "get_task_list":
                result = TaskHandler.get_task_list(request)
            elif intention == "logout":
                result = TaskHandler.logout(request, ip)
            elif intention == "get_plugin_list":
                result = TaskHandler.get_plugin_list(request, ip)
            elif intention == "set_task_status":
                result = TaskHandler.set_task_status(request, ip)
            elif intention == "add_log":
                result = TaskHandler.add_log(request, ip)
            elif intention == "set_task_progress":
                result = TaskHandler.set_task_progress(request, ip)
            else:
                pass
        response = HttpResponse(result,
                                content_type='APPLICATION/OCTET-STREAM')
        response['Content-Length'] = len(result)
        return response

    @staticmethod
    def set_task_progress(request, ip):
        uid = request.get("uhash", "666")
        thash, speed = request.get("values", ["666", 0])
        task = Task.objects.filter(uhash=uid, thash=thash, status__lt=4)
        if task:
            task.update(scan_speed=int(speed))
        else:
            return TaskHandler.nullTask(request, [thash])
        return TaskHandler.nullTask(request)

    @staticmethod
    def add_log(request, ip):
        uid = request.get("uhash", '666')
        thash, level, site, phash, info = request['values']
        Report.objects.create(uhash=uid, thash=thash, pname=Plugin.objects.filter(pk=phash).first().title, level=level,
                              site=site,
                              report=info.replace("\n", "**\n**"))
        task = Task.objects.filter(uhash=uid, thash=thash, status__lt=4)
        if not task:
            return TaskHandler.nullTask(request, [thash])
        return TaskHandler.nullTask(request)

    @staticmethod
    def set_task_status(request, ip):
        thash, level = request['values']
        task = Task.objects.filter(uhash=request.get("uhash", "666"), thash=thash, status__lt=4)
        if task:
            task.update(status=level)
        return TaskHandler.nullTask(request)

    @staticmethod
    def get_plugin_list(request, ip):
        hash_list = request['values'][0]
        uuid = request.get("uuid", "")
        ret = {"uuid": uuid, "result": {}, "stops": [], "error": None}
        plu_list = {}
        for hash in hash_list:
            plugin = Plugin.objects.filter(phash=hash)
            if plugin:
                plugin = plugin.first()
                plu_list[hash] = [plugin.pk, binascii.b2a_hex(zlib.compress(plugin.body, 9))]
                ret['result'] = plu_list
        return TaskHandler.response(json.dumps(ret))

    @staticmethod
    def logout(request, ip):
        uid = request.get("uhash", "")
        node = Node.objects.filter(uhash=uid, ip=ip)
        if node:
            node.first().delete()
        return TaskHandler.nullTask(request)

    @staticmethod
    def login(request, ip):
        global node_num
        uhash = request.get("uhash", "")
        uuid = request.get("uuid", "")
        if num_Lock.acquire():
            node_num += 1
            platform, version = request.get("values", [])
            try:
                Node.objects.create(uhash=uhash, tid=node_num, platform=platform, version=str(version), ip=ip,
                                    times=timezone.now())
            except Exception, e:
                pass
            ret = TaskHandler.response(json.dumps({"uuid": uuid, "result": node_num, "error": None}))
            num_Lock.release()
            return ret

    @staticmethod
    def uhash2pluginhash(uhash):
        tasks = Task.objects.filter(uhash=uhash, status=0)
        plugin_list = set()
        if tasks:
            tasks = tasks.first()
            thash = tasks.thash

            if tasks.myplugin:
                for tmp in task_scanblock_mapper.objects.filter(thash=thash):
                    for phash in plugin_scanblock_mapper.objects.filter(scan_fieldname=tmp.scan_fieldname):
                        if Plugin.objects.filter(phash=phash.phash, private=True, uhash=uhash):
                            plugin_list.add(phash.phash)

            for tmp in task_scanblock_mapper.objects.filter(thash=thash):
                for phash in plugin_scanblock_mapper.objects.filter(scan_fieldname=tmp.scan_fieldname):
                    if Plugin.objects.filter(phash=phash.phash, private=False):
                        plugin_list.add(phash.phash)
            Task.objects.filter(thash=tasks.thash).update(status=1)

            ret = {"anyone": True, "cookie": tasks.cook, "entry": tasks.sites, "maxtask": tasks.max_pages, "nodes": [],
                   "plugins": list(plugin_list), "scanport": tasks.deep_port_scan, "speed": tasks.speed,
                   "subdomain": tasks.sub_domain, "timeout": tasks.timeout, "useragent": tasks.useragent,
                   'disallow': (tasks.exludetext if tasks.exlude else "")}
            return tasks.thash, tasks.sites, base64.encodestring(json.dumps(ret))
        return "", "", ""

    @staticmethod
    def get_task_list(request):
        uhash = request.get("uhash", "")
        uuid = request.get("uuid", "")
        tid, idlethread = request.get("values", [])
        node = Node.objects.filter(uhash=uhash, tid=tid)
        if node:
            node.update(times=timezone.now())
        if idlethread > 0:
            thash, target, plugins_hash = TaskHandler.uhash2pluginhash(uhash)
            if plugins_hash:
                return TaskHandler.response(json.dumps(
                    {"uuid": uuid,
                     "result": {'tasks': [{'policy': plugins_hash, "id": thash, "target": target}], "nodever": "0",
                                "stops": []},
                     "error": None}))
            return TaskHandler.response(
                json.dumps({"uuid": uuid, "result": {"nodever": 0, "stops": [], "tasks": []}, "error": None}))

    @staticmethod
    def nullTask(request, stop=[]):
        uhash = request.get("uhash", "")
        uuid = request.get("uuid", "")
        _ = request.get("values", [])
        ret = TaskHandler.response(
            json.dumps({"uuid": uuid, "result": {"nodever": 0, "stops": stop, "tasks": []}, "error": None}))
        return ret

    @staticmethod
    def response(param):
        return "%s%s%s" % (md5.md5(param).hexdigest(), "|", base64.encodestring(zlib.compress(param, 9)))


def page(request):
    thash = request.path.split("/")[2]
    users = request.session.get("users", {})
    if not users:
        return render(request, "auth.html", {"users": {}, "tasklen": "0"})
    report_list = Report.objects.filter(thash=thash)
    repo_list = json.loads("{}")
    if report_list:
        report_list = report_list.order_by('level').all()
        for line in report_list:
            level = {0: 'success', 1: 'info', 2: 'warning', 3: 'danger'}.get(line.level, 'success')
            pname = str(line.pname).encode('utf-8')
            report = str(line.report).encode("utf-8")
            if repo_list.has_key(line.site):
                if repo_list[line.site].has_key(level):
                    if repo_list[line.site][level].has_key(pname):
                        repo_list[line.site][level][pname].append(report)
                    else:
                        repo_list[line.site][level][pname] = [report]
                else:
                    repo_list[line.site][level] = {}
                    repo_list[line.site][level][pname] = [report]
            else:
                repo_list[line.site] = {}
                repo_list[line.site][level] = {}
                repo_list[line.site][level][pname] = [report]
    return render(request, 'base/report.html', {"users": users, 'report': repo_list})


def view(request):
    return render(request, "view.html", {'urls': "/p/" + request.path.split("/")[-1]})
